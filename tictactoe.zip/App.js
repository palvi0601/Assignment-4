import React, {useState} from "react"
import Icon from "./Components/Icon"
import Popup from "./Components/Popup"


//import react-toastify
import {ToastContainer, toast} from "react-toastify"
import 'react-toastify/dist/ReactToastify.css'

//import reactstrap
import {Button, Container, Row,Col,Card,CardBody } from "reactstrap"
import 'bootstrap/dist/css/bootstrap.css';
import "./style.css"

const tictac = new Array(9).fill("")



const App = () => {

    let [isCross, setisCross] = useState(true);
    let [winMessage, setwinMessage] = useState("");
    let [steps, setSteps] = useState(0);
    let [start, setStart] = useState(true);
    let [buttonpop,setbuttonpop] = useState(false);

    const playAgain = () => {
        setisCross(true);
        tictac.fill("");
        setwinMessage("");
        setSteps(0);
        setStart(true);
    }

    const findWinner = () => {
        console.log(steps)
        
        if(tictac[0] == tictac[1] && tictac[0] == tictac[2] && tictac[0] != "" ){
            return(setwinMessage(tictac[0] + "has won"))
        }
      

        else if(tictac[3] == tictac[4] && tictac[4] == tictac[5] && tictac[3] != "" ){
            return(setwinMessage(tictac[3] + "has won"))
        }
       

        else if(tictac[6] == tictac[7] && tictac[6] == tictac[8] && tictac[6] != "" ){
            return(setwinMessage(tictac[6] + "has won"));
        }
       

        else if(tictac[0] == tictac[3] && tictac[0] == tictac[6] && tictac[0] != "" ){
            return(setwinMessage(tictac[0] + "has won"));
        }
        
        
        else if(tictac[1] == tictac[4] && tictac[1] == tictac[7] && tictac[1] != "" ){
            return(setwinMessage(tictac[1] + "has won"));
        }
        
        
        else if(tictac[2] == tictac[5] && tictac[2] == tictac[8] && tictac[2] != "" ){
            return(setwinMessage(tictac[2] + "has won"));
        }
        
        
        else if(tictac[0] == tictac[4] && tictac[0] == tictac[8] && tictac[0] != "" ){
            return(setwinMessage(tictac[0] + "has won"));
        }
       
        
        else if(tictac[2] == tictac[4] && tictac[2] == tictac[6] && tictac[2] != "" ){
            return(setwinMessage(tictac[2] + "has won"));
        }
        else if (steps==8){
            return(
            setwinMessage("It's Draw!")
            );
        }
        
       
    }


     const changeTurn = (index) => {
         
         if(winMessage){
               return toast("Game over", {type: "success"})
         }
         if(tictac[index] == ""){
             tictac[index] = isCross? "cross" : "circle"
             setisCross(!isCross)
         }
         else{
             return toast ( "Watch out! It's already filled", {type: "error"})
         }
         findWinner()
     }

    return   start? 
        <div className = "main">
        <button  onClick = {()=> setbuttonpop(true)}>start the game </button>
       <Popup trigger = {buttonpop} setTrigger = {setbuttonpop} setisCross = {setisCross} setStart = {setStart} >
       </Popup>
    </div>:
        <Container className = "p-5">
            <ToastContainer position = "bottom-center">
            </ToastContainer>
            <Row>
                <Col md = {6} className = "offset-md-3">
                    {
                        winMessage? (
                            <div>
                                <h1>
                                    {winMessage}
                                </h1>
                                <Button onClick = {playAgain}>Play Again</Button>
                                </div>
                        ) :(  
                            
                              <h1>
                                  {isCross? "Cross turn" : "circle turn"}
                              </h1>
                            
                        )

                    }
                    <div className = "grid"> 
                      {tictac.map((val,index) => (
                        <Card onClick = {()=> {setSteps(steps+1 ); changeTurn(index)} } >
                            <CardBody className = "box">
                                <Icon choice = {tictac[index]}/>
                            </CardBody>
                        </Card>
                       ) )}
                    </div>
                </Col>

            </Row>

        </Container>   
           
}

export default App