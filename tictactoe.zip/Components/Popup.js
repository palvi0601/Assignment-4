import React from 'react'

const Popup = (props) => {
    return props.trigger? (
        <div className = "popup">
            <div className = "popup-in">
                <button className = "closebtn" onClick = {() => {props.setTrigger(false); props.setStart(false)}}> close </button>
                <button onClick = {() => props.setisCross(true)}>cross</button>
           <button onClick = {() => props.setisCross(false)}>circle</button>
            </div>
        </div>
    ):""
}
export default Popup;
